# Plasma Properties
Module for computing properties in plasmas such as transort phenomena, Zbar, etc.

## Installing with pip
Open an terminal and type:

`$ pip install plasma-properties-package`

## Dcoumentation
https://lukestanek.github.io/plasma_properties_package/
